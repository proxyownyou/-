﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Terentev
{
    public partial class zakaz : Form
    {
        public bool session;
        public zakaz(bool login)
        {
            InitializeComponent();
            session = login;    
        }

        private void zakaz_Load(object sender, EventArgs e)
        {
             //TODO: данная строка кода позволяет загрузить данные в таблицу "terentevDataSet.Zakaz". При необходимости она может быть перемещена или удалена.
            this.zakazTableAdapter.Fill(this.terentevDataSet.Zakaz);
            if(session)
            {
                groupBox1.Visible = true;
            }
            else
            {
                this.Size = new Size(583, 274); 
            }
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 fm = new Form1(session);
            this.Close();
            fm.ShowDialog();    

        }

        private void button2_Click(object sender, EventArgs e)
        {
            addZakaz am = new addZakaz(session);
            this.Close();
            am.ShowDialog();    
        }

        private void button3_Click(object sender, EventArgs e)
        {
            red_zakaz rz = new red_zakaz(session);
            this.Close();
            rz.ShowDialog();

        }
    }
}
