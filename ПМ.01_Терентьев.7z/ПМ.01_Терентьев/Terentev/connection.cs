﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Terentev
{
    internal class connection
    {
        internal static string con =  "Data Source=C41211\\SQLEXPRESS;Initial Catalog=Terentev;Integrated Security=True";
    }
}
