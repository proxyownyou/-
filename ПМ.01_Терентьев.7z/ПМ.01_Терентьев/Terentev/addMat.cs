﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Terentev
{
    public partial class addMat : Form
    {
        public bool login;
        public addMat(bool session)
        {
            InitializeComponent();
            login = session;    

        }

        private void addMat_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "terentevDataSet.Materials". При необходимости она может быть перемещена или удалена.
            this.materialsTableAdapter.Fill(this.terentevDataSet.Materials);
            bindingNavigatorAddNewItem.PerformClick();


        }

        private void materialsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.materialsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.terentevDataSet);

        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.materialsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.terentevDataSet);
            MessageBox.Show("Успешно", "Добавлен", MessageBoxButtons.OK);
            Material fm = new Material(login);
            this.Close();
            fm.ShowDialog();

        }
    }
}
