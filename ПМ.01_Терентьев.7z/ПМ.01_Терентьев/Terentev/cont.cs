﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Terentev
{
    
    public partial class cont : Form
    {
        public bool login;
        public cont(bool session)
        {
            InitializeComponent();
            login = session;        
        }

        private void cont_Load(object sender, EventArgs e)
        {

        }
    }
}
