﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace Terentev
{
    public partial class Material : Form
    {
        public bool login;
        public Material(bool session)
        {
            InitializeComponent();
            login = session;
        }

        private void Material_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "terentevDataSet.Materials". При необходимости она может быть перемещена или удалена.
            this.materialsTableAdapter.Fill(this.terentevDataSet.Materials);
            if (login)
            {
                groupBox3.Visible= true;    
            }
            else
            {
                this.Size = new Size(1062, 432);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Sort(кодМатериалаDataGridViewTextBoxColumn, System.ComponentModel.ListSortDirection.Ascending);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            dataGridView1.Sort(ценаDataGridViewTextBoxColumn, System.ComponentModel.ListSortDirection.Ascending);
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            dataGridView1.Sort(ценаDataGridViewTextBoxColumn, System.ComponentModel.ListSortDirection.Descending);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                if (dataGridView1[1,i].Value.ToString()!=textBox1.Text)
                {
                    dataGridView1.Rows.RemoveAt(i);
                    i--;
                }
            }    



        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 fm = new Form1(login);
            this.Close();
            fm.ShowDialog();    
        }

        private void button4_Click(object sender, EventArgs e)
        {
            addMat am = new addMat(login);
            this.Close();
            am.ShowDialog();    
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Вы хотите удалить эту строчку?", "Удалить",MessageBoxButtons.YesNo,MessageBoxIcon.Warning )== DialogResult.Yes)
            {
                if (dataGridView1.SelectedRows.Count >0)
                {
                    int index = dataGridView1.SelectedRows[0].Index;
                    dataGridView1.Rows.RemoveAt(index); 

                }
            }
            else
            {
                return;
            }
            this.Validate();
            this.materialsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.terentevDataSet);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            redMat rm = new redMat(login);
            this.Close();
            rm.ShowDialog();    
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            excelApp.Visible = true;
            Excel.Workbook workbook = excelApp.Workbooks.Add();
            Excel.Worksheet worksheet = workbook.ActiveSheet;
            for(int i =0; i <dataGridView1.ColumnCount;i++)
            {
                worksheet.Cells[1, i + 1] = dataGridView1.Columns[i].HeaderText;
            }
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    var cellValue = dataGridView1.Rows[i].Cells[j].Value;
                    if (cellValue != null)
                    {
                        worksheet.Cells[i + 2, j + 1] = cellValue.ToString();
                    }
                }
            }



        }
    }
}
