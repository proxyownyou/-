﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Terentev
{
    public partial class addZakaz : Form
    {
        public bool login;
        public addZakaz(bool session)
        {
            InitializeComponent();
            login = session;
        }

        private void addZakaz_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "terentevDataSet.Zakaz". При необходимости она может быть перемещена или удалена.
            this.zakazTableAdapter.Fill(this.terentevDataSet.Zakaz);
            bindingNavigatorAddNewItem.PerformClick();

        }

        private void zakazBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.zakazBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.terentevDataSet);

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.zakazBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.terentevDataSet);

            MessageBox.Show("Успешно", "Добавлен", MessageBoxButtons.OK);
            zakaz fm = new zakaz(login);
            this.Close();
            fm.ShowDialog();
        }
    }
}
