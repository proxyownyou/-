﻿namespace Terentev
{
    partial class red_zakaz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(red_zakaz));
            System.Windows.Forms.Label товарLabel;
            System.Windows.Forms.Label количествоLabel;
            System.Windows.Forms.Label поставщикLabel;
            System.Windows.Forms.Label датаЗаказаLabel;
            this.terentevDataSet = new Terentev.TerentevDataSet();
            this.zakazBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zakazTableAdapter = new Terentev.TerentevDataSetTableAdapters.ZakazTableAdapter();
            this.tableAdapterManager = new Terentev.TerentevDataSetTableAdapters.TableAdapterManager();
            this.zakazBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.товарTextBox = new System.Windows.Forms.TextBox();
            this.количествоTextBox = new System.Windows.Forms.TextBox();
            this.поставщикTextBox = new System.Windows.Forms.TextBox();
            this.датаЗаказаDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            товарLabel = new System.Windows.Forms.Label();
            количествоLabel = new System.Windows.Forms.Label();
            поставщикLabel = new System.Windows.Forms.Label();
            датаЗаказаLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.terentevDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazBindingNavigator)).BeginInit();
            this.zakazBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // terentevDataSet
            // 
            this.terentevDataSet.DataSetName = "TerentevDataSet";
            this.terentevDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // zakazBindingSource
            // 
            this.zakazBindingSource.DataMember = "Zakaz";
            this.zakazBindingSource.DataSource = this.terentevDataSet;
            // 
            // zakazTableAdapter
            // 
            this.zakazTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.MaterialsTableAdapter = null;
            this.tableAdapterManager.SuppliersTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Terentev.TerentevDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ZakazTableAdapter = this.zakazTableAdapter;
            // 
            // zakazBindingNavigator
            // 
            this.zakazBindingNavigator.AddNewItem = null;
            this.zakazBindingNavigator.BindingSource = this.zakazBindingSource;
            this.zakazBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.zakazBindingNavigator.DeleteItem = null;
            this.zakazBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorSeparator2});
            this.zakazBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.zakazBindingNavigator.MoveFirstItem = null;
            this.zakazBindingNavigator.MoveLastItem = null;
            this.zakazBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.zakazBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.zakazBindingNavigator.Name = "zakazBindingNavigator";
            this.zakazBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.zakazBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.zakazBindingNavigator.TabIndex = 0;
            this.zakazBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // товарLabel
            // 
            товарLabel.AutoSize = true;
            товарLabel.Location = new System.Drawing.Point(65, 48);
            товарLabel.Name = "товарLabel";
            товарLabel.Size = new System.Drawing.Size(39, 13);
            товарLabel.TabIndex = 1;
            товарLabel.Text = "товар:";
            // 
            // товарTextBox
            // 
            this.товарTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.zakazBindingSource, "товар", true));
            this.товарTextBox.Location = new System.Drawing.Point(110, 45);
            this.товарTextBox.Name = "товарTextBox";
            this.товарTextBox.Size = new System.Drawing.Size(100, 20);
            this.товарTextBox.TabIndex = 2;
            // 
            // количествоLabel
            // 
            количествоLabel.AutoSize = true;
            количествоLabel.Location = new System.Drawing.Point(36, 74);
            количествоLabel.Name = "количествоLabel";
            количествоLabel.Size = new System.Drawing.Size(68, 13);
            количествоLabel.TabIndex = 3;
            количествоLabel.Text = "количество:";
            // 
            // количествоTextBox
            // 
            this.количествоTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.zakazBindingSource, "количество", true));
            this.количествоTextBox.Location = new System.Drawing.Point(110, 71);
            this.количествоTextBox.Name = "количествоTextBox";
            this.количествоTextBox.Size = new System.Drawing.Size(100, 20);
            this.количествоTextBox.TabIndex = 4;
            // 
            // поставщикLabel
            // 
            поставщикLabel.AutoSize = true;
            поставщикLabel.Location = new System.Drawing.Point(38, 100);
            поставщикLabel.Name = "поставщикLabel";
            поставщикLabel.Size = new System.Drawing.Size(66, 13);
            поставщикLabel.TabIndex = 5;
            поставщикLabel.Text = "поставщик:";
            // 
            // поставщикTextBox
            // 
            this.поставщикTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.zakazBindingSource, "поставщик", true));
            this.поставщикTextBox.Location = new System.Drawing.Point(110, 97);
            this.поставщикTextBox.Name = "поставщикTextBox";
            this.поставщикTextBox.Size = new System.Drawing.Size(100, 20);
            this.поставщикTextBox.TabIndex = 6;
            // 
            // датаЗаказаLabel
            // 
            датаЗаказаLabel.AutoSize = true;
            датаЗаказаLabel.Location = new System.Drawing.Point(10, 127);
            датаЗаказаLabel.Name = "датаЗаказаLabel";
            датаЗаказаLabel.Size = new System.Drawing.Size(73, 13);
            датаЗаказаLabel.TabIndex = 7;
            датаЗаказаLabel.Text = "дата Заказа:";
            // 
            // датаЗаказаDateTimePicker
            // 
            this.датаЗаказаDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.zakazBindingSource, "датаЗаказа", true));
            this.датаЗаказаDateTimePicker.Location = new System.Drawing.Point(89, 123);
            this.датаЗаказаDateTimePicker.Name = "датаЗаказаDateTimePicker";
            this.датаЗаказаDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.датаЗаказаDateTimePicker.TabIndex = 8;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(41, 165);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(134, 165);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 10;
            this.button2.Text = "Назад";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // red_zakaz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(датаЗаказаLabel);
            this.Controls.Add(this.датаЗаказаDateTimePicker);
            this.Controls.Add(поставщикLabel);
            this.Controls.Add(this.поставщикTextBox);
            this.Controls.Add(количествоLabel);
            this.Controls.Add(this.количествоTextBox);
            this.Controls.Add(товарLabel);
            this.Controls.Add(this.товарTextBox);
            this.Controls.Add(this.zakazBindingNavigator);
            this.Name = "red_zakaz";
            this.Text = "red_zakaz";
            this.Load += new System.EventHandler(this.red_zakaz_Load);
            ((System.ComponentModel.ISupportInitialize)(this.terentevDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazBindingNavigator)).EndInit();
            this.zakazBindingNavigator.ResumeLayout(false);
            this.zakazBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TerentevDataSet terentevDataSet;
        private System.Windows.Forms.BindingSource zakazBindingSource;
        private TerentevDataSetTableAdapters.ZakazTableAdapter zakazTableAdapter;
        private TerentevDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator zakazBindingNavigator;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.TextBox товарTextBox;
        private System.Windows.Forms.TextBox количествоTextBox;
        private System.Windows.Forms.TextBox поставщикTextBox;
        private System.Windows.Forms.DateTimePicker датаЗаказаDateTimePicker;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}