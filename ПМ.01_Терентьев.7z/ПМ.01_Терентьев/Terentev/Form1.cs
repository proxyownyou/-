﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Terentev
{
    public partial class Form1 : Form
    {
        public bool session = false;
        public Form1(bool login)
        {
            InitializeComponent();
            session= login; 

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if(session)
            {
                label3.Text = "Администратор";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            auth au = new auth(session);
            this.Hide();
            au.Show();

        }

        private void материалыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Material mat = new Material(session);
            this.Hide();
            mat.Show(); 
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void заказыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            zakaz zk = new zakaz(session);
            this.Hide();
            zk.Show();  

        }

        private void контактыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cont ct = new cont(session);
            this.Close();
            ct.Show();
        }
    }
}
