﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Terentev
{
    public partial class auth : Form
    {
        public bool loginis;
        public auth(bool session)
        {
            InitializeComponent();
            loginis = session;  
        }

        private void auth_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text;
            string password = textBox2.Text;    
            if (login == "IIPetrov2021@mail.ru" && password == "isP1") 
            {
                loginis= true;
                MessageBox.Show($"Успешная авторизация, {login}", "Информация", MessageBoxButtons.OK); ; ;
                Form1 fm = new Form1(loginis);
                this.Close();
                fm.Show();
            }
            else
            {
                MessageBox.Show("Введенные данные не верны", "Ошибка", MessageBoxButtons.OK);
            }
        }
    }
}
