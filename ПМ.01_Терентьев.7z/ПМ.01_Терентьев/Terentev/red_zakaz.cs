﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Terentev
{
    public partial class red_zakaz : Form
    {
        public bool login;
        public red_zakaz(bool session)
        {
            InitializeComponent();
            login = session;    
        }

        private void zakazBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.zakazBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.terentevDataSet);

        }

        private void red_zakaz_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "terentevDataSet.Zakaz". При необходимости она может быть перемещена или удалена.
            this.zakazTableAdapter.Fill(this.terentevDataSet.Zakaz);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.zakazBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.terentevDataSet);

            MessageBox.Show("Информация изменена");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            zakaz zk = new zakaz(login);
            this.Close();
            zk.Show();
        }
    }
}
